<?php
// config.php
$host = 'localhost';
$dbname = 'mecanografia';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Crear la tabla si no existe
$sql = "CREATE TABLE IF NOT EXISTS ejercicios_mecanografia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    texto TEXT NOT NULL,
    dificultad VARCHAR(20) NOT NULL,
    tiempo_estimado INT NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

$pdo->exec($sql);
?>

<?php
// crud_operations.php

// Crear nuevo ejercicio
function crearEjercicio($titulo, $texto, $dificultad, $tiempo_estimado) {
    global $pdo;
    $sql = "INSERT INTO ejercicios_mecanografia (titulo, texto, dificultad, tiempo_estimado) 
            VALUES (:titulo, :texto, :dificultad, :tiempo_estimado)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([
        ':titulo' => $titulo,
        ':texto' => $texto,
        ':dificultad' => $dificultad,
        ':tiempo_estimado' => $tiempo_estimado
    ]);
}

// Leer ejercicios
function obtenerEjercicios() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM ejercicios_mecanografia ORDER BY fecha_creacion DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Obtener un ejercicio específico
function obtenerEjercicio($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM ejercicios_mecanografia WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Actualizar ejercicio
function actualizarEjercicio($id, $titulo, $texto, $dificultad, $tiempo_estimado) {
    global $pdo;
    $sql = "UPDATE ejercicios_mecanografia 
            SET titulo = :titulo, texto = :texto, dificultad = :dificultad, tiempo_estimado = :tiempo_estimado 
            WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([
        ':id' => $id,
        ':titulo' => $titulo,
        ':texto' => $texto,
        ':dificultad' => $dificultad,
        ':tiempo_estimado' => $tiempo_estimado
    ]);
}

// Eliminar ejercicio
function eliminarEjercicio($id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM ejercicios_mecanografia WHERE id = ?");
    return $stmt->execute([$id]);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Mecanografía</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .typing-text {
            font-family: monospace;
            font-size: 18px;
            line-height: 1.6;
            margin: 20px 0;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .correct {
            color: green;
            background-color: #e8f5e9;
        }
        .incorrect {
            color: red;
            background-color: #ffebee;
        }
        .cursor {
            border-right: 2px solid #000;
            animation: blink 1s infinite;
        }
        @keyframes blink {
            50% { border-color: transparent; }
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <h1 class="text-center mb-4">Sistema de Mecanografía</h1>
        
        <!-- Formulario para crear/editar ejercicios -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title" id="formTitle">Nuevo Ejercicio</h5>
            </div>
            <div class="card-body">
                <form id="ejercicioForm">
                    <input type="hidden" id="ejercicioId">
                    <div class="mb-3">
                        <label for="titulo" class="form-label">Título</label>
                        <input type="text" class="form-control" id="titulo" required>
                    </div>
                    <div class="mb-3">
                        <label for="texto" class="form-label">Texto del ejercicio</label>
                        <textarea class="form-control" id="texto" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="dificultad" class="form-label">Dificultad</label>
                        <select class="form-select" id="dificultad" required>
                            <option value="Principiante">Principiante</option>
                            <option value="Intermedio">Intermedio</option>
                            <option value="Avanzado">Avanzado</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tiempo_estimado" class="form-label">Tiempo estimado (segundos)</label>
                        <input type="number" class="form-control" id="tiempo_estimado" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                    <button type="button" class="btn btn-secondary" onclick="limpiarFormulario()">Limpiar</button>
                </form>
            </div>
        </div>

        <!-- Lista de ejercicios -->
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Ejercicios disponibles</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Título</th>
                                <th>Dificultad</th>
                                <th>Tiempo est.</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="ejerciciosLista"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modal para práctica -->
        <div class="modal fade" id="practicaModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Práctica de mecanografía</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div id="statsContainer" class="mb-3">
                            <div class="row">
                                <div class="col-md-4">
                                    <p>Tiempo: <span id="timer">0</span>s</p>
                                </div>
                                <div class="col-md-4">
                                    <p>WPM: <span id="wpm">0</span></p>
                                </div>
                                <div class="col-md-4">
                                    <p>Precisión: <span id="accuracy">100</span>%</p>
                                </div>
                            </div>
                        </div>
                        <div id="typingContainer" class="typing-text"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Variables globales
        let ejerciciosData = [];
        let timerInterval;
        let startTime;
        let currentText = '';
        let typedCharacters = 0;
        let mistakes = 0;

        // Funciones CRUD
        async function cargarEjercicios() {
            try {
                const response = await fetch('get_ejercicios.php');
                ejerciciosData = await response.json();
                mostrarEjercicios();
            } catch (error) {
                console.error('Error:', error);
            }
        }

        function mostrarEjercicios() {
            const lista = document.getElementById('ejerciciosLista');
            lista.innerHTML = ejerciciosData.map(ejercicio => `
                <tr>
                    <td>${ejercicio.titulo}</td>
                    <td>${ejercicio.dificultad}</td>
                    <td>${ejercicio.tiempo_estimado}s</td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="iniciarPractica(${ejercicio.id})">Practicar</button>
                        <button class="btn btn-sm btn-warning" onclick="editarEjercicio(${ejercicio.id})">Editar</button>
                        <button class="btn btn-sm btn-danger" onclick="eliminarEjercicio(${ejercicio.id})">Eliminar</button>
                    </td>
                </tr>
            `).join('');
        }

        // Funciones de práctica
        function iniciarPractica(id) {
            const ejercicio = ejerciciosData.find(e => e.id === id);
            if (!ejercicio) return;

            currentText = ejercicio.texto;
            const typingContainer = document.getElementById('typingContainer');
            typingContainer.innerHTML = currentText.split('').map(char => 
                `<span class="character">${char}</span>`
            ).join('');

            // Reiniciar estadísticas
            typedCharacters = 0;
            mistakes = 0;
            document.getElementById('wpm').textContent = '0';
            document.getElementById('accuracy').textContent = '100';
            document.getElementById('timer').textContent = '0';

            // Mostrar modal
            const modal = new bootstrap.Modal(document.getElementById('practicaModal'));
            modal.show();

            // Iniciar timer
            startTime = new Date();
            if (timerInterval) clearInterval(timerInterval);
            timerInterval = setInterval(actualizarEstadisticas, 1000);

            // Agregar event listener para teclas
            document.addEventListener('keypress', manejarTecla);
        }

        function manejarTecla(e) {
            const chars = document.querySelectorAll('.character');
            if (typedCharacters < chars.length) {
                const expectedChar = currentText[typedCharacters];
                const typedChar = e.key;

                if (typedChar === expectedChar) {
                    chars[typedCharacters].classList.add('correct');
                } else {
                    chars[typedCharacters].classList.add('incorrect');
                    mistakes++;
                }

                typedCharacters++;
                actualizarEstadisticas();

                // Verificar si se completó el ejercicio
                if (typedCharacters === chars.length) {
                    clearInterval(timerInterval);
                    alert('¡Ejercicio completado!');
                }
            }
        }

        function actualizarEstadisticas() {
            const timeElapsed = Math.floor((new Date() - startTime) / 1000);
            const wpm = Math.round((typedCharacters / 5) / (timeElapsed / 60));
            const accuracy = Math.round(((typedCharacters - mistakes) / typedCharacters) * 100) || 100;

            document.getElementById('timer').textContent = timeElapsed;
            document.getElementById('wpm').textContent = wpm;
            document.getElementById('accuracy').textContent = accuracy;
        }

        // Event Listeners
        document.getElementById('ejercicioForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = {
                id: document.getElementById('ejercicioId').value,
                titulo: document.getElementById('titulo').value,
                texto: document.getElementById('texto').value,
                dificultad: document.getElementById('dificultad').value,
                tiempo_estimado: document.getElementById('tiempo_estimado').value
            };

            try {
                const response = await fetch('save_ejercicio.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    alert('Ejercicio guardado exitosamente');
                    limpiarFormulario();
                    cargarEjercicios();
                }
            } catch (error) {
                console.error('Error:', error);
            }
        });

        function limpiarFormulario() {
            document.getElementById('ejercicioForm').reset();
            document.getElementById('ejercicioId').value = '';
            document.getElementById('formTitle').textContent = 'Nuevo Ejercicio';
        }

        // Cargar ejercicios al iniciar
        cargarEjercicios();
    </script>
</body>
</html>

<?php
// get_ejercicios.php
require_once 'config.php';
header('Content-Type: application/json');
echo json_encode(obtenerEjercicios());
?>

<?php
// save_ejercicio.php
require_once 'config.php';

header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['id']) && !empty($data['id'])) {
    // Actualizar
    $result = actualizarEjercicio(
        $data['id'],
        $data['titulo'],
        $data['texto'],
        $data['dificultad'],
        $data['tiempo_estimado']
    );
} else {
    // Crear nuevo
    $result = crearEjercicio(
        $data['titulo'],
        $data['texto'],
        $data['dificultad'],
        $data['tiempo_estimado']
    );
}

echo json_encode(['success' => $result]);
?>

<?php
// delete_ejercicio.php
require_once 'config.php';

header('Content-Type: application/json');
$id = $_POST['id'] ?? null;

if ($id) {
    $result = eliminarEjercicio($id);
    echo json_encode(['success' => $result]);
} else {
    echo json_encode(['success' => false, 'error' => 'ID no proporcionado']);
}
?>